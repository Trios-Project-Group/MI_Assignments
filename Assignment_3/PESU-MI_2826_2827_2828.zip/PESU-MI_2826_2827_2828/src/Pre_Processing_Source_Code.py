import pandas as pd
import numpy as np

#Function to fill missing values for weight. 
def fill_weight():
        df = data['Weight'].copy()
        for i in range(len(data['Weight'])):
                if(np.isnan(data['Weight'][i])):
                        v1 = 0
                        v2 = 0
                        category = data['Community'][i]
                        for j in range(i-1,-1,-1):
                                if(category==data['Community'][j]):
                                        v1 = df[j]
                                        break
                        for k in range(i+1,len(data['Weight'])):
                                if(category==data['Community'][k] and not(np.isnan(df[k]))):
                                        v2 = df[k]
                                        break
                        if(v1!=0 and v2!=0):
                                res = (v1+v2)/2
                        elif(v1==0):
                                res = v2
                        else:
                                res = v1
                        df[i] = round(res,0)
        data['Weight'] = df

#Initial Preprocessing is done which is commented as the updated csv file is used after data is stored.
if __name__ == "__main__":
    #Read the csv file
    data = pd.read_csv("LBW_Dataset.csv")
	
    #Data Preprocessing:
	
    #Fill missing values of Age with mean as they almost follow a normal distribution and unknown would be varying on either side of median:
    data['Age'].fillna(value=round(data['Age'].mean(),0), inplace=True)
	
	#Filling Nan values of Weight based on the average nearest weights of another women belonging to same community of upper and lower values in the same column. 
    fill_weight()
	
    #Missing values in Delivery Phase is filled with 1 as those missing values belong to below 24 years age and all below 24 years are having 1 as value. 
    data['Delivery phase'].fillna(value='1', inplace=True)
	
    #Again HB is a normal distribution hence is replaced with mean value.
    data['HB'].fillna(value=round(data['HB'].mean(), 1), inplace=True)
	
    #BP has an outlier, hence mean is not choosen as its more prone to outlier instead median is choosen as less prone to outliers.
    data['BP'].fillna(value=data['BP'].median(), inplace=True)

    #All values are 5 hence is replaced with 5 using bfill.
    data['Education'].fillna(method='bfill', inplace=True)
	
    #Missing values are replaced by 1 for residence as all those which are missing belong to community 1 and most of community one are residents of same town
    data['Residence'].fillna(value=1, inplace=True)
	
    #Stored it into one csv file.
    data.to_csv("LBW_Preprocessed_Dataset.csv", index=False)